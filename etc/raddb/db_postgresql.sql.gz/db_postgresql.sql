SET client_encoding = 'SQL_ASCII';
SET check_function_bodies = false;
SET client_min_messages = warning;
CREATE DATABASE radius WITH TEMPLATE = template0 ENCODING = 'SQL_ASCII';
ALTER DATABASE radius OWNER TO radius;
\connect radius
SET client_encoding = 'SQL_ASCII';
SET check_function_bodies = false;
SET client_min_messages = warning;
COMMENT ON SCHEMA public IS 'Standard public schema';
SET search_path = public, pg_catalog;
CREATE FUNCTION plpgsql_call_handler() RETURNS language_handler
    AS '$libdir/plpgsql', 'plpgsql_call_handler'
    LANGUAGE c;
ALTER FUNCTION public.plpgsql_call_handler() OWNER TO pgsql;
CREATE FUNCTION plpgsql_validator(oid) RETURNS void
    AS '$libdir/plpgsql', 'plpgsql_validator'
    LANGUAGE c;
ALTER FUNCTION public.plpgsql_validator(oid) OWNER TO pgsql;
CREATE TRUSTED PROCEDURAL LANGUAGE plpgsql HANDLER plpgsql_call_handler VALIDATOR plpgsql_validator;
CREATE FUNCTION date_sub(date, integer, text) RETURNS date
    AS $_$
DECLARE
        var1 date;
        var2 text;
BEGIN
        var2 = $2 || ' ' || $3;
        SELECT INTO var1
                to_date($1 - var2::interval, 'YYYY-MM-DD');
RETURN var1;
END;$_$
    LANGUAGE plpgsql;
ALTER FUNCTION public.date_sub(date, integer, text) OWNER TO pgsql;
SET default_tablespace = '';
SET default_with_oids = true;
CREATE TABLE nas (
    ipaddr inet NOT NULL,
    shortname character varying(32) NOT NULL,
    secret character varying(60) NOT NULL,
    nasname character varying(128),
    "type" character varying(30),
    ports integer,
    community character varying(50),
    snmp character varying(10),
    naslocation character varying(32)
);
ALTER TABLE public.nas OWNER TO radius;
CREATE TABLE radacct (
    radacctid bigserial NOT NULL,
    acctsessionid character varying(32) NOT NULL,
    acctuniqueid character varying(32) NOT NULL,
    username character varying(253),
    realm character varying(30),
    nasipaddress inet NOT NULL,
    nasportid bigint,
    nasporttype character varying(32),
    acctstarttime timestamp with time zone,
    acctstoptime timestamp with time zone,
    acctsessiontime bigint,
    acctauthentic character varying(32),
    connectinfo_start character varying(32),
    connectinfo_stop character varying(32),
    acctinputoctets bigint,
    acctoutputoctets bigint,
    calledstationid character varying(50),
    callingstationid character varying(50),
    acctterminatecause character varying(32),
    servicetype character varying(32),
    framedprotocol character varying(32),
    framedipaddress inet,
    acctstartdelay bigint,
    acctstopdelay bigint
);
ALTER TABLE public.radacct OWNER TO radius;
CREATE TABLE radcheck (
    id serial NOT NULL,
    username character varying(30) DEFAULT ''::character varying NOT NULL,
    attribute character varying(30),
    op character varying(2) DEFAULT '=='::character varying NOT NULL,
    value character varying(40)
);
ALTER TABLE public.radcheck OWNER TO radius;
CREATE TABLE radgroupcheck (
    id serial NOT NULL,
    groupname character varying(20) DEFAULT ''::character varying NOT NULL,
    attribute character varying(40),
    op character varying(2) DEFAULT '=='::character varying NOT NULL,
    value character varying(40)
);
ALTER TABLE public.radgroupcheck OWNER TO radius;
CREATE TABLE radgroupreply (
    id serial NOT NULL,
    groupname character varying(20) DEFAULT ''::character varying NOT NULL,
    attribute character varying(40),
    op character varying(2) DEFAULT '='::character varying NOT NULL,
    value character varying(40)
);
ALTER TABLE public.radgroupreply OWNER TO radius;
CREATE TABLE radpostauth (
    id bigserial NOT NULL,
    username character varying(253) NOT NULL,
    pass character varying(128),
    reply character varying(32),
    authdate timestamp with time zone DEFAULT '2006-02-19 14:19:50.047383+02'::timestamp with time zone NOT NULL
);
ALTER TABLE public.radpostauth OWNER TO radius;
CREATE TABLE radreply (
    id serial NOT NULL,
    username character varying(30) DEFAULT ''::character varying NOT NULL,
    attribute character varying(30),
    op character varying(2) DEFAULT '='::character varying NOT NULL,
    value character varying(40)
);
ALTER TABLE public.radreply OWNER TO radius;
CREATE TABLE realmgroup (
    id serial NOT NULL,
    realmname character varying(30) DEFAULT ''::character varying NOT NULL,
    groupname character varying(30)
);
ALTER TABLE public.realmgroup OWNER TO radius;
CREATE TABLE realms (
    id serial NOT NULL,
    realmname character varying(64),
    nas character varying(128),
    authport integer,
    options character varying(128) DEFAULT ''::character varying
);
ALTER TABLE public.realms OWNER TO radius;
CREATE TABLE usergroup (
    id serial NOT NULL,
    username character varying(30) DEFAULT ''::character varying NOT NULL,
    groupname character varying(30)
);
ALTER TABLE public.usergroup OWNER TO radius;
ALTER TABLE ONLY nas
    ADD CONSTRAINT nas_pkey PRIMARY KEY (ipaddr);
ALTER INDEX public.nas_pkey OWNER TO radius;
ALTER TABLE ONLY radacct
    ADD CONSTRAINT radacct_pkey PRIMARY KEY (radacctid);
ALTER INDEX public.radacct_pkey OWNER TO radius;
ALTER TABLE ONLY radcheck
    ADD CONSTRAINT radcheck_pkey PRIMARY KEY (id);
ALTER INDEX public.radcheck_pkey OWNER TO radius;
ALTER TABLE ONLY radgroupcheck
    ADD CONSTRAINT radgroupcheck_pkey PRIMARY KEY (id);
ALTER INDEX public.radgroupcheck_pkey OWNER TO radius;
ALTER TABLE ONLY radgroupreply
    ADD CONSTRAINT radgroupreply_pkey PRIMARY KEY (id);
ALTER INDEX public.radgroupreply_pkey OWNER TO radius;
ALTER TABLE ONLY radpostauth
    ADD CONSTRAINT radpostauth_pkey PRIMARY KEY (id);
ALTER INDEX public.radpostauth_pkey OWNER TO radius;
ALTER TABLE ONLY radreply
    ADD CONSTRAINT radreply_pkey PRIMARY KEY (id);
ALTER INDEX public.radreply_pkey OWNER TO radius;
ALTER TABLE ONLY realmgroup
    ADD CONSTRAINT realmgroup_pkey PRIMARY KEY (id);
ALTER INDEX public.realmgroup_pkey OWNER TO radius;
ALTER TABLE ONLY realms
    ADD CONSTRAINT realms_pkey PRIMARY KEY (id);
ALTER INDEX public.realms_pkey OWNER TO radius;
ALTER TABLE ONLY usergroup
    ADD CONSTRAINT usergroup_pkey PRIMARY KEY (id);
ALTER INDEX public.usergroup_pkey OWNER TO radius;
CREATE INDEX radacct_active_user_idx ON radacct USING btree (username) WHERE (acctstoptime IS NULL);
ALTER INDEX public.radacct_active_user_idx OWNER TO radius;
CREATE INDEX radacct_start_user_idx ON radacct USING btree (acctstarttime, username);
ALTER INDEX public.radacct_start_user_idx OWNER TO radius;
CREATE INDEX radcheck_username ON radcheck USING btree (username, attribute);
ALTER INDEX public.radcheck_username OWNER TO radius;
CREATE INDEX radgroupcheck_groupname ON radgroupcheck USING btree (groupname, attribute);
ALTER INDEX public.radgroupcheck_groupname OWNER TO radius;
CREATE INDEX radgroupreply_groupname ON radgroupreply USING btree (groupname, attribute);
ALTER INDEX public.radgroupreply_groupname OWNER TO radius;
CREATE INDEX radreply_username ON radreply USING btree (username, attribute);
ALTER INDEX public.radreply_username OWNER TO radius;
CREATE INDEX realmgroup_realmname ON realmgroup USING btree (realmname);
ALTER INDEX public.realmgroup_realmname OWNER TO radius;
CREATE INDEX usergroup_username ON usergroup USING btree (username);
ALTER INDEX public.usergroup_username OWNER TO radius;
REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM pgsql;
GRANT ALL ON SCHEMA public TO pgsql;
GRANT ALL ON SCHEMA public TO PUBLIC;
